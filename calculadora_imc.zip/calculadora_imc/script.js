function limparResultado() {
    document.getElementById('resultado').style.display = 'none';
}
