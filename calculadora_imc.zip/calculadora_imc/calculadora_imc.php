<?php
// Habilitar exibição de erros para depuração
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Verifica se o método de requisição é POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Validação e sanitização dos dados
    if (isset($_POST["peso"]) && isset($_POST["altura"])) {
        $peso = str_replace(',', '.', $_POST["peso"]);
        $altura = str_replace(',', '.', $_POST["altura"]);

        // Converte os valores para float
        $peso = floatval($peso);
        $altura = floatval($altura);

        // Verifica se os valores são positivos e válidos
        if ($peso > 0 && $altura > 0) {
            // Converte altura de centímetros para metros
            $altura_metros = $altura / 100;

            // Calcula o IMC
            $imc = $peso / ($altura_metros * $altura_metros);

            // Formata o resultado com duas casas decimais
            $imc_formatado = number_format($imc, 2, ',', '.');

            // Determina a classificação do IMC
            if ($imc < 18.5) {
                $resultado = "Você está abaixo do peso ideal";
            } elseif ($imc < 24.9) {
                $resultado = "Você está no peso ideal";
            } elseif ($imc < 29.9) {
                $resultado = "Você está com sobrepeso";
            } else {
                $resultado = "Você está obeso, CUIDADO!!!";
            }

            // Exibe o resultado
            echo "<div id='resultado' class='result' style='display:block;'>
                    Seu IMC é: $imc_formatado<br>
                    Classificação: $resultado
                  </div>";

            // Adiciona o botão "Voltar"
            echo "<div style='text-align: center; margin-top: 20px;'>
                    <button onclick='window.location.href=\"index.html\"'>Voltar</button>
                  </div>";
        } else {
            echo "<div id='resultado' class='result' style='display:block;'>
                    Por favor, insira valores válidos para peso e altura.
                  </div>";
        }
    } else {
        echo "<div id='resultado' class='result' style='display:block;'>
                Por favor, preencha todos os campos do formulário.
              </div>";
    }
}
?>
